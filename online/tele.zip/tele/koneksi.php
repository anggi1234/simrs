<?php
$serverName = "192.168.1.234, 50201"; //serverName\instanceName
$connectionInfo = array( "Database"=>"RSUD_copy", "UID"=>"sa", "PWD"=>"Agussalim7");
$conn = sqlsrv_connect( $serverName, $connectionInfo);

if( $conn ) {
     echo "Connection established.<br />";
}else{
     echo "Connection could not be established.<br />";
     die( print_r( sqlsrv_errors(), true));
}
?>
