<?php
include "koneksi.php";

$path = "https://api.telegram.org/bot1937412324:AAH3UK2ZQQFUdkxPxLMwOYYoDV7yLJev1_c"; //Ganti dengan Token yang diperoleh dari BotFather

$update = json_decode(file_get_contents("php://input"), TRUE);

$chatId = $update["message"]["chat"]["id"];
$message = $update["message"]["text"];
$nama = $update["message"]["from"]["first_name"];

if (strpos($message, "/start") === 0) { 
  $balasan = "Selamat datang $nama";
};

if (strpos($message, "ya") === 0) { 
    $balasan = "Selamat datang $nama";
  };
// if (strpos($message, "Daftar") === 0) { 
//   //$message = trim($message); //proses membersihkan teks  
//   $nama = $pecah[1];
//   $norm = $pecah[2];
//   $no_hp = $pecah[3];
//   $id = base_convert(microtime(false), 10, 36);
//   //$id = 'rnvui3s91vp';
 
//   $sql = "INSERT INTO telegram(id, nama, norm, no_hp) VALUES ('$id','$nama','$norm','$no_hp')";
//   mysqli_query($conn, $sql);

    
//   //$conn = mysqli_connect($servername, $username, $password, $dbname);  
//     $sql = "SELECT * FROM telegram WHERE id = '$id' ";
// 	$result = mysqli_query($conn, $sql);
//     $row = mysqli_fetch_assoc($result);
//     $no_antrian =   $row['no_antrian']; //$row['no_antrian'];
//    // echo $no_antrian;
//     //echo $row['no_antrian'];
	

//   $balasan = "Selamat, reservasi berhasil! "                                                                                           
//             . " Nama:$nama"
//             . " norm:$norm" 
//             . " No hp:$no_hp" 
//     		. " No Antrian:$no_antrian" ;

file_get_contents($path . "/sendmessage?chat_id=" . $chatId."&text=$balasan "  ) ;  
// echo "$sql  <br>";
// echo $balasan;
  
  //mysqli_close($conn);

}
?>